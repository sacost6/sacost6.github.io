# Rock-Paper-Scissors-Spock-Lizard
Rock, Paper, Scissors with two extra twists!
This application implements the logic for a client-server program that handles
gameplay for a variation of rock, paper, scissors. The client program handles input 
and displaying game information, but the server deals with the scorekeeping and game 
details. This program is written in Java and uses sockets to connect clients and the server.
I also used JavaFX to deal with the GUI portion of the application.

To run: 
1) Download zip
2) Import to IDE and configure the settings for both
   the server and client programs.
3) Once the server is running, you must have two clients connect
   in order for the game to begin.
   
 Rules: https://the-big-bang-theory.com/rock-paper-scissors-lizard-spock/
 
 ** This project was written for a class ** 
