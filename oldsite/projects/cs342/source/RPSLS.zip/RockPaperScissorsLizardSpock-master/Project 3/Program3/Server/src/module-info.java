module untitled2 {
    requires javafx.fxml;
    requires javafx.controls;

    opens sample;
}