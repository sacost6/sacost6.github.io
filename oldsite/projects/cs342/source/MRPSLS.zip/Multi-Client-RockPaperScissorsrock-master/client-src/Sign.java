package code;

/*
    Basic hand signs for the game
 */
public enum Sign {
    Rock, Paper, Scissors, Lizard, Spock
}
