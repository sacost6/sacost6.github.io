# ArduinoPotholeDetector

This project was designed for CS362 (Computer Design) for a final semester project. This project uses Arduino hardware, Arduino code, Python Code, and a MySQL database in order to store the coordinates of potholes and detect when a user is approaching an already-registered pothole. 
