
namespace program.Models
{

  public class Line
	{
	
		// data members with auto-generated getters and setters:
        public string LineColor; 
        public int LineID;
        public int NumStops;
        public string stopName;
        public int StationID;
		// default constructor:
		public Line()
		{ }
		
	
		
	}//class

}//namespace