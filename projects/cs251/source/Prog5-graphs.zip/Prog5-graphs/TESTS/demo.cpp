
#include <iostream>
#include "Graph.h"


int main(){
  graph g;
  
  
  g.add_edge("a", "b");
  g.add_edge("a", "c");

  g.add_edge("b", "d");
  g.add_edge("b", "e");
  g.add_edge("c", "f");
  g.add_edge("c", "g");
  
  
  g.valid_topo_order(
  g.display();

  return 0;
}

