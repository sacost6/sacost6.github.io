
#include <iostream>
#include "Graph.h"


int main(){
  graph g;
  std::vector<graph::vertex_label> rpt;
  
  
  g.add_edge("a", "b");
  g.add_edge("a", "c");
  g.add_edge("b", "d");
  g.add_edge("b", "e");
  g.add_edge("c", "f");
  g.add_edge("c", "g");

  g.bfs("a", rpt);
  std::vector<int> path;
  g.display();
  g.extract_path(rpt, 5, path);
  g.disp_report(rpt);
  for(int i = 0; i < rpt.size(); i++) {
    std::cout << "rpt[" << i <<"].pred: " << g.id2name(rpt[i].pred) << std::endl;
  }
  
  for(int i = 0; i < path.size(); i++) {
    std::cout << "path[" << i <<"]: " << g.id2name(path[i]) << std::endl;
  }
  return 0;
}

